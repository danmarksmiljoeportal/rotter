﻿using Dmp.Rotte.Integration.Sample.Rest;
using IdentityModel.Client;
using IdentityModel.OidcClient;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Dmp.Jord.Integration.Sample.Rest
{
    public class RestFactory
    {
        public static async Task<RotteClient> CreateAsync(string apiUrl)
        {
            var oidcClient = InitializeLoginClient();

            Console.WriteLine("Logging in");
            var loginResult = await Login(oidcClient);

            // Request a new access token using the refresh token if it is expired.
            //var refreshResult = await oidcClient.RefreshTokenAsync(loginResult.RefreshToken);
            //Console.WriteLine(refreshResult.IdentityToken);

            var httpClient = new HttpClient();
            httpClient.SetBearerToken(loginResult.AccessToken);

            Console.WriteLine("Initializing Jord client");
            var jordClient = new RotteClient(apiUrl, httpClient);

            return jordClient;
        }


        private static OidcClient InitializeLoginClient()
        {
            int port = 7279;

            string authority = "https://log-in.test.miljoeportal.dk/runtime/oauth2";

            string clientId = "** insert client id **";
            string clientSecret = "** insert client secret **";

            string redirectUri = string.Format($"https://localhost:{port}/swagger/oauth2-redirect.html");


            var options = new OidcClientOptions
            {
                Authority = authority,

                Policy = new Policy
                {
                    Discovery = new DiscoveryPolicy
                    {
                        ValidateIssuerName = false,
                        ValidateEndpoints = false
                    }
                },

                ClientId = clientId,
                ClientSecret = clientSecret,
                RedirectUri = redirectUri,

                Scope = "openid",

                Flow = OidcClientOptions.AuthenticationFlow.AuthorizationCode,
                ResponseMode = OidcClientOptions.AuthorizeResponseMode.Redirect,

                Browser = new SystemBrowser(port)
            };

            var client = new OidcClient(options);

            return client;
        }

        private static async Task<LoginResult> Login(OidcClient client)
        {
            var request = new LoginRequest();
            var result = await client.LoginAsync(request);

            return result;
        }
    }
}
