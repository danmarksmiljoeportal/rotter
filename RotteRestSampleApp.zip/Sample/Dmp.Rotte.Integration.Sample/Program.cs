﻿using Dmp.Jord.Integration.Sample.Rest;
using Dmp.Rotte.Integration.Sample.Rest;
using System;
using System.Threading.Tasks;


namespace Dmp.Rotte.Integration.Sample
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var apiUrl = "https://rotte.test.miljoeportal.dk/api";
            var rotteClient = await RestFactory.CreateAsync(apiUrl);
            await AccountAsync(rotteClient);
        }

        private static async Task AccountAsync(RotteClient rotteClient)
        {
            Console.WriteLine("Calling AccountAsync");
            var result = await rotteClient.AccountAsync("en-US");
            Console.WriteLine("AccountAsync response: " + result);
        }

    }
}
